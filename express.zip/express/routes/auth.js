const express = require('express');
const router = express.Router();
var template = require('../lib/template.js');   
var db = require('../lib/db');
const bcrypt = require('bcrypt');

//const post = require('./topic.js');
var shortid = require('shortid');

module.exports = function(passport) {

  router.get('/login', function(request, response) {
    var fmsg = request.flash();
    var feedback = "";
    if(fmsg.error) {
      feedback = fmsg.error[0];
    }
    var title = 'login';
    var list = template.list(request.list);
    var html = template.HTML(title, list, `
      <form action="/auth/login_process" method="post">
        <p><input type="text" name="id" placeholder="id"></p>
        <p><input type="password" name="password" placeholder="password"></p>
        <p><input type="submit" value="login"></p>
      </form>
    `, '');
    response.send(html);
  });


  router.post('/login_process',
    passport.authenticate('local', { 
      //successRedirect: '/',
      failureRedirect: '/auth/login', 
      failureFlash:true,
      successFlash:true
    }),
    function(req, res) {
      req.session.save(function(){
      console.log('세션 저장확인 완료');
      res.redirect('/');
      })
    });
  // router.post('/login_process', function(req, res, next) {
  //   passport.authenticate('local', function(err, user, info) {
  //     if (err) {
  //       return next(err); // will generate a 500 error
  //     }
  //     // Generate a JSON response reflecting authentication status
  //     if (! user) {
  //       return res.send(401,{ success : false, message : 'authentication failed' });
  //     }
  //     req.login(user, function(err){
  //       if(err){
  //         return next(err);
  //       }
  //       return res.send({ success : true, message : 'authentication succeeded' });        
  //     });
  //   })(req, res, next);
  // });


  router.get('/logout', function(request, response) {
    console.log('start');
    request.logout();
    request.session.save(function() {
      console.log('donee');
      response.redirect('/');
    });
  });

  router.get('/register', function(request, response) {
    var fmsg = request.flash();
    var feedback = "";
    if(fmsg.error) {
      feedback = fmsg.error[0];
    }
    var title = 'Register';
    var html = template.HTML(title, '', `
      <form action="/auth/register_process" method="post">
        <p><input type="text" name="id" placeholder="id"></p>
        <p><input type="password" name="password" placeholder="password"></p>
        <p><input type="password" name="password2" placeholder="confirm_password"></p>
        <p><input type="text" name="nickname" placeholder="nickname"></p>
        <p><input type="submit" value="login"></p>
      </form>
    `, '');
    response.send(html);
  });

  router.post('/register_process', function(request, response) {
    var post = request.body;
    var id = post.id;
    var password = post.password;
    var password2 = post.password2;
    var nickname = post.nickname;

    if(password != password2) {
      request.flash('error', 'Password must same!');
      response.redirect('/auth/register');
    } else {
      bcrypt.hash(password, 10, function(err, hash) {
        var user = {
          shortid:shortid.generate(),
          id:id,
          password:hash,
          nickname:nickname
        }
        db.get('user').push(user).write();
        request.login(user, function(err) {
          return response.redirect('/');
        });
      });
    }
  });


  return router ;
}


  
// router.post('/login_process', function(request, response) {
//     var post = request.body;
//     var id = post.id;
//     var password = post.password;
//     if(id === authData.id && password === authData.password) {
//       request.session.is_logined = true ;
//       request.session.nickname = authData.nickname ;
//       console.log('ok~~');
//       console.log(request.session);
//       request.session.save(function() {
//         response.redirect(`/`);
//       });
//     } else {
//       response.send('Who??');
//     }

// });

