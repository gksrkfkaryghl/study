var a = 1;
console.log(a);
a = 2;
console.log(a);
// 1 = 2; comment
